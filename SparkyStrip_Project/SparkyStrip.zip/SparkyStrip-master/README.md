# SparkyStrip
