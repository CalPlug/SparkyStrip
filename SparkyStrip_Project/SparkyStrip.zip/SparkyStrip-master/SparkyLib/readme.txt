Libraries for the arduino projects. Place a symbolic link to this folder in the Arduino libraries folder.

At least on my macbook the command to do this is:
ln -s <path to project>/SparkyStrip/SparkyLib /Users/$USER/Documents/Arduino/libraries/SparkyLib