//
//  SimSwitch.h
//  SparkySim
//
//  Created by Jeffrey Thompson on 4/14/16.
//  Copyright © 2016 Jeffrey Thompson. All rights reserved.
//

#ifndef SimSwitch_h
#define SimSwitch_h

#define SIMULATION



#endif /* SimSwitch_h */
